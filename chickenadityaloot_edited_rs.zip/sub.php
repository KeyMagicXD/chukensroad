<?php
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login");
    exit;
}
require_once "config.php";
$sql = "SELECT  password,balance FROM users WHERE username='".$_SESSION['username']."'";
$result = $conn->query($sql);
$row = mysqli_fetch_array($result);
$withdraw="";
$withdrawerr="";



if (empty($_POST["withdraw"] )== false){
if ($_POST["password"]  ==  $row['password']){


                   if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    if (empty($_POST["withdraw"])) {
                        echo '<div data-v-51265586="" class="text_field">
<p data-v-51265586="" style="text-align:center;" >Please enter the amount to withdraw</p>
</div>';
                      
                    } else {
                      $withdraw1 = $_POST['withdraw'];
                      $withdraw = $withdraw1-(4/100*$withdraw1);
                    }

                    
                  
                  }
                  if($withdraw == ""){
                    echo '<div data-v-51265586="" class="text_field">
                    <p data-v-51265586="" style="text-align:center;" >Please enter the amount to withdraw </p>
                    </div>';
                  }elseif($row['balance']<=$withdraw1){
                       header("location: recharge");
                  }else{

                  $newbalance = $row['balance'] - $withdraw1;
                   $sql = "UPDATE users SET withdraw ='$withdraw', balance = '$newbalance' WHERE username='".$_SESSION['username']."' ";

                  if ($conn->query($sql) === TRUE) {
                    header("location: withdrawrec");
                  
                  } else {
                    echo "Error updating record: " . $conn->error;
                  }
                                   function random_strings($length_of_string)
{
  
    // String of all alphanumeric character
    $str_result = '0123456789AZ012345678901234567890123456789';
  
    // Shuffle the $str_result and returns substring
    // of specified length
    return substr(str_shuffle($str_result), 
                       0, $length_of_string);
}

$pre="MGWS";
$r=random_strings(23);

  
$rand=$pre.$r;
                 $sql = "INSERT INTO record (username, withdraw,rand) VALUES ('".$_SESSION['username']."', $withdraw,'$rand')";
                
                if ($conn->query($sql) === TRUE) {
                 
                
                } else {
                  echo "Error updating record: " . $conn->error;
                }


                  }
                 
                }else{
                    echo '<div data-v-51265586="" class="text_field">
<p data-v-51265586="" style="text-align:center;" >Incorrect Password</p>
</div>';
                }
              
                
             
           
         
    }
                $conn->close();
?>