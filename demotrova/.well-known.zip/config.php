<?php
/*
This file contains database config.phpuration assuming you are running mysql using user "root" and password ""
*/

define('DB_SERVER', '127.0.0.1');
define('DB_USERNAME', 'u861307671_dream');
define('DB_PASSWORD', 'Dream@123');
define('DB_NAME', 'u861307671_dream');

// Try connecting to the Database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

//Check the connection
if($conn == false){
    dir('Error: Cannot connect');
    Echo"Fail";
}

?>
