<?php


define('DB_SERVER', '127.0.0.1');
define('DB_USERNAME', 'u861307671_dream');
define('DB_PASSWORD', 'Dream@123');
define('DB_NAME', 'u861307671_dream');

// Try connecting to the Database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

//Check the connection
if($conn == false){
    dir('Error: Cannot connect');
}
  

$sql3 = "SELECT * FROM users WHERE balance!='0'";
$result3 =$conn->query($sql3);

//display the retrieved result on the webpage  
while ($row3 = mysqli_fetch_array($result3)) {  
$user=$row3['username'];
$balance=$row3['balance'];
$intrest=(2/100*$balance);
    $addwin0="UPDATE users SET balance= balance +($intrest/2) WHERE username=$user ";
    $conn->query($addwin0);
$rec="INSERT INTO intrest (username,amount) VALUES ($user,$intrest)";
$conn->query($rec);
    
}


?>